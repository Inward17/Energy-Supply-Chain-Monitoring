import { headerKpis } from "./data"

const toneMap = {
  emerald: "text-emerald-400",
  rose: "text-rose-500",
  cyan: "text-cyan-400",
} as const

export function KpiHeader() {
  return (
    <div className="grid grid-cols-2 gap-y-4 rounded-lg border border-slate-800 bg-slate-900/40 px-4 py-4 sm:grid-cols-3 lg:grid-cols-5">
      {headerKpis.map((kpi, i) => (
        <div
          key={kpi.label}
          className={`px-4 ${i !== 0 ? "lg:border-l lg:border-slate-800" : ""}`}
        >
          <p className="text-[11px] uppercase tracking-widest text-slate-500">{kpi.label}</p>
          <p className="mt-1 flex items-baseline gap-1.5">
            <span className="font-mono text-2xl font-bold text-white">{kpi.value}</span>
            {kpi.unit && <span className="text-xs text-slate-500">{kpi.unit}</span>}
          </p>
          <p className={`mt-0.5 text-[11px] ${toneMap[kpi.tone]}`}>{kpi.sub}</p>
        </div>
      ))}
    </div>
  )
}
