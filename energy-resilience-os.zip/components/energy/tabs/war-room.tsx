"use client"

import { useState } from "react"
import { Swords, Loader, ShieldAlert, Crosshair, Droplet, Activity } from "lucide-react"
import { Panel } from "../ui"
import { crisisScenarios, targetRefineries, warRoomReroute } from "../data"

type Phase = "idle" | "loading" | "done"

export function WarRoom() {
  const [scenario, setScenario] = useState(crisisScenarios[1])
  const [refinery, setRefinery] = useState(targetRefineries[0])
  const [phase, setPhase] = useState<Phase>("idle")

  function simulate() {
    setPhase("loading")
    setTimeout(() => setPhase("done"), 1600)
  }

  return (
    <div className="space-y-4">
      <Panel title="Executive War Room" icon={<Swords className="h-4 w-4 text-rose-500" />}>
        <div className="space-y-4 p-4">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-[11px] font-medium uppercase tracking-wider text-slate-400">
                Select Crisis Scenario
              </label>
              <select
                value={scenario}
                onChange={(e) => {
                  setScenario(e.target.value)
                  setPhase("idle")
                }}
                className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-200 outline-none focus:border-rose-500"
              >
                {crisisScenarios.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-[11px] font-medium uppercase tracking-wider text-slate-400">
                Target Refinery
              </label>
              <select
                value={refinery}
                onChange={(e) => {
                  setRefinery(e.target.value)
                  setPhase("idle")
                }}
                className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-200 outline-none focus:border-rose-500"
              >
                {targetRefineries.map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="button"
            onClick={simulate}
            disabled={phase === "loading"}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-3.5 text-base font-bold tracking-wide text-white shadow-lg shadow-rose-900/40 transition-colors hover:bg-rose-500 disabled:opacity-70"
          >
            {phase === "loading" ? (
              <>
                <Loader className="h-5 w-5 animate-spin" />
                RUNNING SIMULATION...
              </>
            ) : (
              <>
                <ShieldAlert className="h-5 w-5" />
                SIMULATE SCENARIO
              </>
            )}
          </button>
        </div>
      </Panel>

      {phase === "loading" && <LoadingSkeleton />}

      {phase === "done" && (
        <div className="space-y-4">
          {/* Section 1: Reroute */}
          <Panel title="Optimal Reroute Strategy" icon={<Crosshair className="h-4 w-4 text-cyan-400" />}>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-left text-[11px] uppercase tracking-wider text-slate-500">
                    <th className="px-4 py-2.5 font-medium">Export Terminal</th>
                    <th className="px-4 py-2.5 font-medium">Crude Grade</th>
                    <th className="px-4 py-2.5 font-medium">Landed Cost</th>
                    <th className="px-4 py-2.5 font-medium">Lead Time</th>
                  </tr>
                </thead>
                <tbody>
                  {warRoomReroute.map((r, i) => (
                    <tr
                      key={r.terminal}
                      className={`border-b border-slate-800/60 last:border-0 ${i === 0 ? "bg-emerald-500/10" : ""}`}
                    >
                      <td className="px-4 py-2.5 font-medium text-slate-200">{r.terminal}</td>
                      <td className="px-4 py-2.5 text-slate-400">{r.grade}</td>
                      <td className="px-4 py-2.5 font-mono text-slate-200">{r.landed}</td>
                      <td className="px-4 py-2.5 font-mono text-cyan-400">{r.lead}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>

          {/* Section 2: SPR trajectory KPIs */}
          <Panel title="SPR Trajectory" icon={<Droplet className="h-4 w-4 text-cyan-400" />}>
            <div className="grid grid-cols-1 gap-4 p-4 sm:grid-cols-3">
              <BigKpi label="SPR Survival Days" value="41.6" unit="days" accent="text-cyan-400" />
              <BigKpi label="Supply Gap" value="0.0" unit="days · SAFE" accent="text-emerald-400" />
              <BigKpi label="GDP Impact" value="-0.000" unit="%" accent="text-emerald-400" />
            </div>
          </Panel>

          {/* Section 3: Executive brief */}
          <Panel title="Ministry of Petroleum — Executive Brief" icon={<Activity className="h-4 w-4 text-cyan-400" />}>
            <div className="p-4">
              <div className="space-y-3 rounded-md border-l-4 border-blue-500 bg-blue-900/20 p-4 text-sm leading-relaxed text-slate-300">
                <p>
                  <span className="font-semibold text-blue-300">Situation.</span> {scenario} is projected to
                  interdict primary inbound flows to {refinery}, removing an estimated 2.16 mbpd of feedstock
                  from the near-term balance. Sentinel modeling assigns an 85% probability of sustained
                  disruption over a 14-day horizon, with secondary insurance and freight repricing already
                  observable across affected lanes.
                </p>
                <p>
                  <span className="font-semibold text-blue-300">Recommended Response.</span> Activate the
                  ranked reroute strategy anchored on Novorossiysk (Urals) at a landed cost of $71.20 and a
                  9-day lead time, supplemented by Ceyhan and Ras Tanura as redundancy. Pair the physical
                  reroute with a staged SPR draw and refinery run-rate optimization to fully close the supply
                  gap and hold the survival window above 40 days.
                </p>
                <p>
                  <span className="font-semibold text-blue-300">Outlook.</span> Under the optimized plan the
                  modeled supply gap collapses to 0.0 days and projected GDP impact is neutralized to -0.000%.
                  We advise maintaining demand-management assets in an armed posture and re-running this
                  scenario every six hours until the affected chokepoint returns to nominal risk.
                </p>
              </div>
            </div>
          </Panel>
        </div>
      )}
    </div>
  )
}

function BigKpi({
  label,
  value,
  unit,
  accent,
}: {
  label: string
  value: string
  unit: string
  accent: string
}) {
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4 text-center">
      <p className="text-[11px] uppercase tracking-widest text-slate-500">{label}</p>
      <p className={`mt-2 font-mono text-4xl font-bold ${accent}`}>{value}</p>
      <p className="mt-1 text-xs text-slate-500">{unit}</p>
    </div>
  )
}

function LoadingSkeleton() {
  return (
    <div className="space-y-4">
      <Panel>
        <div className="space-y-3 p-4">
          <div className="h-4 w-48 animate-pulse rounded bg-slate-800" />
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-8 w-full animate-pulse rounded bg-slate-800/70" />
          ))}
        </div>
      </Panel>
      <Panel>
        <div className="grid grid-cols-3 gap-4 p-4">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-24 animate-pulse rounded-lg bg-slate-800/70" />
          ))}
        </div>
      </Panel>
    </div>
  )
}
