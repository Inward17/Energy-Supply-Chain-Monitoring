"use client"

import { useState } from "react"
import { Crosshair, Anchor } from "lucide-react"
import { Panel, StatChip } from "../ui"
import { chokepoints, targetRefineries, rerouteAlternatives } from "../data"

export function RerouteMatrix() {
  const [generated, setGenerated] = useState(true)
  const [blocked, setBlocked] = useState(chokepoints[0].name)
  const [dest, setDest] = useState(targetRefineries[0])

  return (
    <Panel title="Reroute Matrix" icon={<Crosshair className="h-4 w-4 text-cyan-400" />}>
      <div className="space-y-4 p-4">
        {/* Controls */}
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <Field label="Blocked Chokepoint">
            <select
              value={blocked}
              onChange={(e) => setBlocked(e.target.value)}
              className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-500"
            >
              {chokepoints.map((c) => (
                <option key={c.name}>{c.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Destination Refinery">
            <select
              value={dest}
              onChange={(e) => setDest(e.target.value)}
              className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-500"
            >
              {targetRefineries.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </Field>
          <div className="flex items-end">
            <button
              type="button"
              onClick={() => setGenerated(true)}
              className="w-full rounded-md bg-cyan-500 px-4 py-2 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-400"
            >
              Generate Reroute Matrix
            </button>
          </div>
        </div>

        {generated && (
          <>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <StatChip label="Resilience Index" value="0.78" accent="text-emerald-400" />
              <StatChip label="Brent Spot" value="$72.38" accent="text-cyan-400" />
              <StatChip label="Viable Sources" value="5" accent="text-white" />
            </div>

            <div className="overflow-x-auto rounded-lg border border-slate-800">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-left text-[11px] uppercase tracking-wider text-slate-500">
                    <th className="px-4 py-2.5 font-medium">Export Terminal</th>
                    <th className="px-4 py-2.5 font-medium">Country</th>
                    <th className="px-4 py-2.5 font-medium">Crude Grade</th>
                    <th className="px-4 py-2.5 font-medium">Landed Cost</th>
                    <th className="px-4 py-2.5 font-medium">Freight Premium</th>
                    <th className="px-4 py-2.5 font-medium">Lead Time</th>
                  </tr>
                </thead>
                <tbody>
                  {rerouteAlternatives.map((r) => (
                    <tr
                      key={r.terminal}
                      className={`border-b border-slate-800/60 last:border-0 ${
                        r.top ? "bg-emerald-500/10" : ""
                      }`}
                    >
                      <td className="px-4 py-2.5 font-medium text-slate-200">
                        <span className="flex items-center gap-2">
                          {r.top && <Anchor className="h-3.5 w-3.5 text-emerald-400" />}
                          {r.terminal}
                          {r.top && (
                            <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold tracking-wider text-emerald-400">
                              TOP PICK
                            </span>
                          )}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-slate-400">{r.country}</td>
                      <td className="px-4 py-2.5 text-slate-400">{r.grade}</td>
                      <td className="px-4 py-2.5 font-mono text-slate-200">{r.landed}</td>
                      <td className="px-4 py-2.5 font-mono text-orange-400">{r.freight}</td>
                      <td className="px-4 py-2.5 font-mono text-cyan-400">{r.lead}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </Panel>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1.5 block text-[11px] font-medium uppercase tracking-wider text-slate-400">
        {label}
      </label>
      {children}
    </div>
  )
}
