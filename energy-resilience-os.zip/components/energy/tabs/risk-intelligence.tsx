"use client"

import { CircleDot, Activity, Crosshair } from "lucide-react"
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { Panel, SeverityBadge } from "../ui"
import { riskEvents, sdiTimeline, chokepoints } from "../data"
import { chartTooltip } from "../chart-tooltip"

export function RiskIntelligence() {
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
      <Panel
        title="Sentinel Risk Events"
        icon={<CircleDot className="h-4 w-4 text-rose-500" />}
        className="lg:col-span-2"
      >
        <div className="max-h-[560px] space-y-2.5 overflow-y-auto p-3">
          {riskEvents.map((e) => (
            <article
              key={e.id}
              className="rounded-lg border border-slate-800 bg-slate-950/60 p-3 transition-colors hover:border-slate-700"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-sm font-semibold text-white">{e.title}</h3>
                  <p className="text-xs text-cyan-400">{e.region}</p>
                </div>
                <SeverityBadge severity={e.severity} />
              </div>
              <p className="mt-2 text-xs leading-relaxed text-slate-400">{e.detail}</p>
              <p className="mt-2 text-[10px] uppercase tracking-wider text-slate-600">{e.time}</p>
            </article>
          ))}
        </div>
      </Panel>

      <div className="flex flex-col gap-4 lg:col-span-3">
        <Panel title="SDI Score Timeline" icon={<Activity className="h-4 w-4 text-cyan-400" />}>
          <div className="h-64 p-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sdiTimeline} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="t" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} domain={[0, 100]} />
                <Tooltip content={chartTooltip} />
                <Line
                  type="monotone"
                  dataKey="sdi"
                  stroke="#facc15"
                  strokeWidth={2}
                  dot={{ r: 2, fill: "#facc15" }}
                  activeDot={{ r: 4 }}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel title="Chokepoint Risk Matrix" icon={<Crosshair className="h-4 w-4 text-cyan-400" />}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-left text-[11px] uppercase tracking-wider text-slate-500">
                  <th className="px-4 py-2.5 font-medium">Chokepoint</th>
                  <th className="px-4 py-2.5 font-medium">Flow</th>
                  <th className="px-4 py-2.5 font-medium">Risk Score</th>
                  <th className="px-4 py-2.5 font-medium">Price Impact</th>
                </tr>
              </thead>
              <tbody>
                {chokepoints.map((c) => (
                  <tr key={c.name} className="border-b border-slate-800/60 last:border-0">
                    <td className="px-4 py-2.5 font-medium text-slate-200">{c.name}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-400">{c.flow}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-16 overflow-hidden rounded-full bg-slate-800">
                          <div
                            className={`h-full rounded-full ${
                              c.risk > 0.6 ? "bg-rose-500" : c.risk > 0.4 ? "bg-orange-400" : "bg-emerald-400"
                            }`}
                            style={{ width: `${c.risk * 100}%` }}
                          />
                        </div>
                        <span className="font-mono text-xs text-slate-300">{c.risk.toFixed(2)}</span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-rose-400">{c.impact}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </div>
    </div>
  )
}
