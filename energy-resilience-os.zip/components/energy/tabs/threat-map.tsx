import { Globe, Ship, Flame } from "lucide-react"
import { Panel } from "../ui"
import { vessels } from "../data"

export function ThreatMap() {
  return (
    <Panel title="Global Threat Map" icon={<Globe className="h-4 w-4 text-cyan-400" />}>
      <div className="p-4">
        <div
          className="relative h-[540px] w-full overflow-hidden rounded-lg border border-slate-800 bg-slate-950"
          style={{
            backgroundImage:
              "linear-gradient(to right, rgba(148,163,184,0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,0.08) 1px, transparent 1px)",
            backgroundSize: "44px 44px",
          }}
        >
          {/* Middle East risk heatmap */}
          <div
            className="pointer-events-none absolute h-72 w-72 rounded-full"
            style={{
              left: "58%",
              top: "38%",
              transform: "translate(-50%, -50%)",
              background:
                "radial-gradient(circle, rgba(244,63,94,0.55) 0%, rgba(249,115,22,0.28) 40%, rgba(249,115,22,0) 70%)",
            }}
          />
          <div
            className="absolute flex items-center gap-1.5 rounded-md border border-rose-500/40 bg-slate-950/80 px-2 py-1 text-[11px] font-medium text-rose-400"
            style={{ left: "58%", top: "38%", transform: "translate(-50%, -50%)" }}
          >
            <Flame className="h-3.5 w-3.5" />
            Persian Gulf · CRITICAL
          </div>

          {/* Vessels */}
          {vessels.map((v) => (
            <div key={v.id} className="absolute" style={{ left: `${v.x}%`, top: `${v.y}%` }}>
              <span className="absolute -inset-1.5 animate-ping rounded-full bg-cyan-400/40" />
              <span className="relative block h-2 w-2 rounded-full bg-cyan-400 shadow-[0_0_8px_2px_rgba(34,211,238,0.7)]" />
            </div>
          ))}

          {/* Legend */}
          <div className="absolute bottom-3 left-3 flex flex-col gap-1.5 rounded-md border border-slate-800 bg-slate-950/80 px-3 py-2 text-[11px] text-slate-300 backdrop-blur-sm">
            <span className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-cyan-400 shadow-[0_0_6px_1px_rgba(34,211,238,0.7)]" />
              Tracked Vessel
            </span>
            <span className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-rose-500" />
              Risk Heatmap
            </span>
          </div>

          <div className="absolute right-3 top-3 flex items-center gap-1.5 rounded-md border border-slate-800 bg-slate-950/80 px-3 py-1.5 text-[11px] font-medium text-cyan-300">
            <Ship className="h-3.5 w-3.5" />
            500 vessels live
          </div>
        </div>
      </div>
    </Panel>
  )
}
