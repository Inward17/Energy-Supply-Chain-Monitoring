// Mock data for the Energy Supply Chain Resilience OS

export const REGIONS = [
  "All Regions",
  "Persian Gulf",
  "Russia / Black Sea",
  "North America",
  "West Africa",
  "Southeast Asia",
] as const

export const liveMetrics = {
  sdi: 72.5,
  vesselsTracked: 500,
  activeAlerts: 4,
  brent: 72.38,
  priceImpact: 0.17,
}

export const headerKpis = [
  {
    label: "SDI Score",
    value: "72.5",
    unit: "/ 100",
    sub: "P_risk = 0.85",
    tone: "emerald" as const,
  },
  {
    label: "Top Risk Region",
    value: "Russia",
    unit: "",
    sub: "Sanctions + conflict",
    tone: "rose" as const,
  },
  {
    label: "Vessel Density Δ",
    value: "0.33",
    unit: "",
    sub: "vs baseline",
    tone: "rose" as const,
  },
  {
    label: "Brent ΔP (norm)",
    value: "1.00",
    unit: "",
    sub: "normalized index",
    tone: "cyan" as const,
  },
  {
    label: "Chokepoints at Risk",
    value: "0",
    unit: "",
    sub: "None",
    tone: "emerald" as const,
  },
]

export type Severity = "CRITICAL" | "HIGH" | "MODERATE" | "LOW"

export const riskEvents: {
  id: number
  title: string
  region: string
  severity: Severity
  time: string
  detail: string
}[] = [
  {
    id: 1,
    title: "Military Conflict",
    region: "Persian Gulf",
    severity: "CRITICAL",
    time: "12m ago",
    detail: "Naval skirmish reported near Strait of Hormuz shipping lane.",
  },
  {
    id: 2,
    title: "Port Blockade Threat",
    region: "Black Sea",
    severity: "HIGH",
    time: "48m ago",
    detail: "Insurers withdrawing coverage for Novorossiysk-bound tankers.",
  },
  {
    id: 3,
    title: "Drone Activity",
    region: "Red Sea / Suez",
    severity: "HIGH",
    time: "1h 20m ago",
    detail: "Elevated UAV interceptions along Bab-el-Mandeb approach.",
  },
  {
    id: 4,
    title: "Sanctions Expansion",
    region: "Russia",
    severity: "MODERATE",
    time: "3h ago",
    detail: "New secondary sanctions targeting shadow-fleet operators.",
  },
  {
    id: 5,
    title: "Cyclone Warning",
    region: "Southeast Asia",
    severity: "MODERATE",
    time: "5h ago",
    detail: "Tropical system tracking toward Malacca Strait traffic.",
  },
  {
    id: 6,
    title: "Labor Strike",
    region: "West Africa",
    severity: "LOW",
    time: "8h ago",
    detail: "Terminal workers threaten slowdown at Bonny export hub.",
  },
]

export const sdiTimeline = [
  { t: "00:00", sdi: 41 },
  { t: "03:00", sdi: 44 },
  { t: "06:00", sdi: 52 },
  { t: "09:00", sdi: 49 },
  { t: "12:00", sdi: 58 },
  { t: "15:00", sdi: 66 },
  { t: "18:00", sdi: 63 },
  { t: "21:00", sdi: 70 },
  { t: "Now", sdi: 72.5 },
]

export const chokepoints = [
  { name: "Strait of Hormuz", flow: "21.0 mbpd", risk: 0.82, impact: "+$4.10" },
  { name: "Strait of Malacca", flow: "16.0 mbpd", risk: 0.31, impact: "+$1.20" },
  { name: "Suez Canal", flow: "5.5 mbpd", risk: 0.58, impact: "+$2.35" },
  { name: "Bab-el-Mandeb", flow: "6.2 mbpd", risk: 0.61, impact: "+$2.60" },
  { name: "Bosphorus", flow: "2.4 mbpd", risk: 0.44, impact: "+$0.95" },
  { name: "Danish Straits", flow: "3.2 mbpd", risk: 0.19, impact: "+$0.40" },
]

export const instruments = [
  { key: "BRENT", label: "Brent Crude", price: 72.38, high: 89.12, low: 68.4, vol: "412k" },
  { key: "NATGAS", label: "Natural Gas", price: 2.71, high: 3.64, low: 2.31, vol: "188k" },
  { key: "USO", label: "USO", price: 74.9, high: 84.2, low: 69.1, vol: "9.4M" },
  { key: "XLE", label: "XLE", price: 91.44, high: 98.7, low: 82.6, vol: "12.1M" },
]

export const priceSeries = [
  { d: "Day 1", price: 88.4, ma: 87.1, vol: 320 },
  { d: "Day 8", price: 86.1, ma: 86.4, vol: 280 },
  { d: "Day 15", price: 84.9, ma: 85.2, vol: 410 },
  { d: "Day 22", price: 82.0, ma: 83.6, vol: 360 },
  { d: "Day 29", price: 79.5, ma: 81.4, vol: 450 },
  { d: "Day 36", price: 77.8, ma: 79.2, vol: 390 },
  { d: "Day 43", price: 75.1, ma: 76.9, vol: 520 },
  { d: "Day 50", price: 73.6, ma: 74.8, vol: 470 },
  { d: "Day 60", price: 72.38, ma: 73.1, vol: 412 },
]

export const rerouteAlternatives = [
  {
    terminal: "Novorossiysk",
    country: "Russia",
    grade: "Urals",
    landed: "$71.20",
    freight: "+$1.90",
    lead: "9 days",
    top: true,
  },
  { terminal: "Ceyhan", country: "Turkey", grade: "Azeri Light", landed: "$74.60", freight: "+$3.10", lead: "11 days", top: false },
  { terminal: "Ras Tanura", country: "Saudi Arabia", grade: "Arab Light", landed: "$75.90", freight: "+$4.40", lead: "16 days", top: false },
  { terminal: "Bonny", country: "Nigeria", grade: "Bonny Light", landed: "$77.20", freight: "+$5.05", lead: "18 days", top: false },
  { terminal: "Houston", country: "USA", grade: "WTI Midland", landed: "$79.80", freight: "+$6.60", lead: "21 days", top: false },
]

export const sprBurndown = [
  { day: 0, baseline: 100, managed: 100 },
  { day: 3, baseline: 90, managed: 93 },
  { day: 6, baseline: 79, managed: 86 },
  { day: 9, baseline: 68, managed: 79 },
  { day: 12, baseline: 55, managed: 71 },
  { day: 15, baseline: 43, managed: 64 },
  { day: 18, baseline: 30, managed: 58 },
  { day: 21, baseline: 18, managed: 53 },
  { day: 24, baseline: 6, managed: 49 },
]

export const sprSites = [
  { name: "Bryan Mound, TX", pct: 82 },
  { name: "Big Hill, TX", pct: 64 },
  { name: "West Hackberry, LA", pct: 71 },
  { name: "Bayou Choctaw, LA", pct: 58 },
]

export const demandPlaybook = [
  { action: "Refinery Run-Rate Cut", impact: "0.60 mbpd", status: "Ready" },
  { action: "Strategic Draw Release", impact: "1.10 mbpd", status: "Armed" },
  { action: "Odd/Even Rationing", impact: "0.40 mbpd", status: "Standby" },
  { action: "Industrial Curtailment", impact: "0.35 mbpd", status: "Standby" },
]

export const crisisScenarios = [
  "Scenario A: Hormuz Mine Closure",
  "Scenario B: Suez Canal Drone Strikes",
  "Scenario C: Black Sea Naval Blockade",
  "Scenario D: Malacca Piracy Surge",
]

export const targetRefineries = [
  "Leuna, Germany",
  "Rotterdam, Netherlands",
  "Jamnagar, India",
  "Ulsan, South Korea",
]

export const warRoomReroute = [
  { terminal: "Novorossiysk", grade: "Urals", landed: "$71.20", lead: "9 days" },
  { terminal: "Ceyhan", grade: "Azeri Light", landed: "$74.60", lead: "11 days" },
  { terminal: "Ras Tanura", grade: "Arab Light", landed: "$75.90", lead: "16 days" },
]

// Vessel positions expressed as % within the map viewport
export const vessels = [
  { id: 1, x: 22, y: 44 },
  { id: 2, x: 31, y: 38 },
  { id: 3, x: 46, y: 55 },
  { id: 4, x: 58, y: 47 },
  { id: 5, x: 61, y: 62 },
  { id: 6, x: 64, y: 40 },
  { id: 7, x: 72, y: 58 },
  { id: 8, x: 78, y: 49 },
  { id: 9, x: 40, y: 68 },
  { id: 10, x: 35, y: 30 },
  { id: 11, x: 52, y: 33 },
  { id: 12, x: 84, y: 66 },
  { id: 13, x: 18, y: 60 },
  { id: 14, x: 67, y: 71 },
  { id: 15, x: 49, y: 24 },
]
